<?php

namespace Custom\Libraries;

/**
 * Class AutoLoad
 * @package Custom\Libraries
 */
class AutoLoad
{
    /**
     * AutoLoad constructor.
     */
    public function __construct()
    {
        $ci = get_instance();

        $ci->load->library('Arr');
        $ci->load->library('CurrentContact');
    }
}