<?php

namespace Custom\Libraries;

use RightNow\Models\Contact;

/**
 * Class CurrentContact
 * @package Custom\Libraries
 */
class CurrentContact
{
    /**
     * @var \CI_Base
     */
    protected $CI;

    /**
     * Contact constructor.
     */
    public function __construct()
    {
        $this->CI = get_instance();
    }

    /**
     * Get the authenticated contact
     *
     * @return CurrentContact|Null
     */
    public function current()
    {
        return $this->CI->model('Contact')->get($this->getId())->result;
    }

    /**
     * Get the id of the authenticated Contact
     *
     * @return integer
     */
    public function getId()
    {
        return $this->CI->session->getProfileData('contactID');
    }

    /**
     * Get all the organisations Ids for the current Contact
     *
     * @param $contact
     *
     * @return array
     */
    public function getOrganisationIds($organization, &$ids = [])
    {
        if ($organization->Parent) {
            $this->getOrganisationIds($organization->Parent, $ids);
        }

        $ids[] = $organization->ID;

        return $ids;
    }


}