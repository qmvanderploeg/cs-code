<?php

namespace Custom\Models;

use RightNow\Models\Base;

use RightNow\Connect\v1_3 as RNCPHP;

/**
 * Class ContactNotification
 *
 * @property int $ID
 * @property int $ContactID
 * @property int $NotificationID
 * @property string $ReadAt
 * @property string $DismissedAt
 *
 * @package Custom\Models
 */
class ContactNotification extends Base
{
    /**
     * Get the ContactNotification that belongs to the notification for the current Contact
     *
     * @param int $contactID
     * @param int $notificationID
     *
     * @return mixed
     */
    public function getSingle($contactID, $notificationID)
    {
        $result = RNCPHP\CS\ContactNotification::first("ContactID = $contactID AND NotificationID = $notificationID");

        return $result;
    }

    /**
     * Find the ContactNotification that belongs to the Notification for the current Contact
     * Or if none exists return a new ContactNotification
     *
     * @param int $contactID
     * @param int $notificationID
     *
     * @return mixed
     */
    public function findOrNew($contactID, $notificationID)
    {
        $result = RNCPHP\CS\ContactNotification::first("ContactID = $contactID AND NotificationID = $notificationID");

        if ($result === null) {
            $result = new RNCPHP\CS\ContactNotification();

            $result->ContactID = $contactID;
            $result->NotificationID = $notificationID;
        }

        return $result;
    }

    /**
     * Remove the ContactNotification that belongs for the Notification for the current Contact
     *
     * @param $contactID
     * @param $notificationID
     *
     * @return void
     */
    public function remove($contactID, $notificationID)
    {
        $result = RNCPHP\CS\ContactNotification::first("ContactID = $contactID AND NotificationID = $notificationID");
        if ($result) {
            $result->destroy();
        }
    }
}