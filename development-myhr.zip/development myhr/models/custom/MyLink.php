<?php

namespace Custom\Models;

use RightNow\Models\Base;

use RightNow\Connect\v1_3 as RNCPHP;

/**
 * Class MyLink
 * @package Custom\Models
 */
class MyLink extends Base
{
    /**
     * Get My Links For the current Contact
     *
     * @param $contactID
     * @param $favorite
     *
     * @return mixed
     */
    public function getForContact($contactID, $favorite = false)
    {
        $favorite = (int) $favorite;
        $result = RNCPHP\CS\MyLink::find("ContactID = $contactID AND Favorite = $favorite ORDER BY Ordering");

        return $result;
    }

    /**
     * Get a single MyLink that belongs to the Contact
     *
     * @param $ID
     * @param $contactID
     *
     * @return mixed
     */
    public function getSingle($ID, $contactID)
    {
        $result = RNCPHP\CS\MyLink::first("ID = $ID AND ContactID = $contactID");

        return $result;
    }


    /**
     * Update or Create a Link
     *
     * @param int $ID
     * @param int $contactID
     * @param string $title
     * @param string $url
     * @param string $iconClass
     * @param string $ordering
     * @param boolean
     *
     * @return mixed
     */
    public function updateOrCreate($ID, $contactID, $title, $url, $iconClass, $ordering = null, $favorite = null)
    {
        $result = RNCPHP\CS\MyLink::first("ID = $ID AND ContactID = $contactID");

        if ($result == null) {

            $result = new RNCPHP\CS\MyLink();

            $result->ContactID = $contactID;
            $result->Ordering = $ordering;
        }

        $result->Title = $title;
        $result->Url = $url;
        $result->IconClass = $iconClass;
        if ($favorite !== null) {
            $result->Favorite = (int) $favorite;
        }
        $result->save();

        return $result;
    }

    /**
     * Save the Link as Favorite
     *
     * @param $ID
     * @param $contactID
     * @param bool $ordering
     */
    public function saveAsFavorite($ID, $contactID, $ordering)
    {
        $result = RNCPHP\CS\MyLink::first("ID = $ID AND ContactID = $contactID");

        if ($result) {
            $result->Favorite = 1;
            $result->Ordering = $ordering;
            $result->save();
        }
    }

    /**
     * Save the Order of MyLink
     *
     * @param $ID
     * @param $contactID
     * @param $ordering
     */
    public function saveOrdering($ID, $contactID, $ordering)
    {
        $result = RNCPHP\CS\MyLink::first("ID = $ID AND ContactID = $contactID");

        if ($result) {
            $result->Favorite = 0;
            $result->Ordering = $ordering;
            $result->save();
        }
    }

    /**
     * Remove myLink on ID and $contactID
     *
     * @param $ID
     * @param $contactID
     *
     * @return boolean
     */
    public function remove($ID, $contactID)
    {
        $result = RNCPHP\CS\MyLink::first("ID = $ID AND ContactID = $contactID");
        if ($result) {
            $result->destroy();
            return true;
        }

        return false;
    }

}