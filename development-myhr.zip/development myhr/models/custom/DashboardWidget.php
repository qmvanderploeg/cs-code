<?php

namespace Custom\Models;

use RightNow\Models\Base;

use RightNow\Connect\v1_3 as RNCPHP;

/**
 * Class DashboardWidget
 * @package Custom\Models
 */
class DashboardWidget extends Base
{
    /**
     * Get the Dashboard Widgets
     *
     * @return mixed
     */
    public function get()
    {
        $result = RNCPHP\CS\DashboardWidget::find("(Type = 'required' OR Type = 'default') AND Enabled = 1 ORDER BY DefaultOrder");

        return $result;
    }

    /**
     * Get the Dashboard on the id
     *
     * @param $ID
     *
     * @return mixed
     */
    public function getSingle($ID)
    {
        $result = RNCPHP\CS\DashboardWidget::fetch("$ID");

        return $result;
    }

    /**
     * Get all the required widgets
     *
     * @return mixed
     */
    public function getRequired()
    {
        $result = RNCPHP\CS\DashboardWidget::find("Type = 'required' AND Enabled = 1 ORDER BY DefaultOrder");

        return $result;
    }

    /**
     * Get All the available DashboardWidgets
     *
     * @return mixed
     */
    public function getAvailable()
    {
        $result = RNCPHP\CS\DashboardWidget::find("Type = 'optional' AND Enabled = 1 ORDER BY DefaultOrder");

        return $result;
    }
}