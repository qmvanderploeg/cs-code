<?php

namespace Custom\Models;

use RightNow\Models\Base;

use RightNow\Connect\v1_3 as RNCPHP;

/**
 * Class ContactDashboardWidget
 * @package Custom\Models
 */
class ContactDashboardWidget extends Base
{
    /**
     * Get the ContactDashboardWidget on contact id
     *
     * @param $contactID
     *
     * @return mixed
     */
    public function getForContact($contactID)
    {
        $result = RNCPHP\CS\ContDashboardWidget::find("ContactID = $contactID ORDER BY Ordering");

        return $result;
    }

    /**
     * Find the ContactNotification that belongs to the Notification for the current Contact
     * Or if none exists return a new ContactNotification
     *
     * @param int $contactID
     * @param int $dashboardWidgetID
     * @param int $ordering
     *
     * @return mixed
     */
    public function updateOrCreate($contactID, $dashboardWidgetID, $ordering)
    {
        $result = RNCPHP\CS\ContDashboardWidget::first("ContactID = $contactID AND DashboardWidgetID = $dashboardWidgetID");

        if ($result === null) {
            $result = new RNCPHP\CS\ContDashboardWidget();

            $result->ContactID = $contactID;
            $result->DashboardWidgetID = $dashboardWidgetID;
        }

        $result->Ordering = $ordering;
        $result->save();

        return $result;
    }

    /**
     * Remove the ContDashboardWidget that belongs to the DashboardWidget for the current Contact
     *
     * @param $contactID
     * @param $dashboardWidgetID
     *
     * @return void
     */
    public function remove($contactID, $dashboardWidgetID)
    {
        $result = RNCPHP\CS\ContDashboardWidget::first("ContactID = $contactID");
        if ($result) {
            $result->destroy();
        }
    }
}