<?php

namespace Custom\Models;

use RightNow\Models\Base;
use RightNow\Connect\v1_3 as RNCPHP;

/**
 * Class Notification
 *
 * @property integer $ID
 * @property string $Title
 * @property string $Text
 * @property string $Link
 * @property object $Contact
 * @property object $Organisation
 * @property string $Source
 * @property string $NotificationCategory
 * @property string $createdAt
 * @property object CreatedByAccount
 * @property object ContactNotification
 * @package Custom\Models
 */
class Notification extends Base
{

    /**
     * Get all the notification for a Contact
     *
     * @param int $contactID
     * @param array $organisationIDs
     * @param int|null $limit
     *
     * @return array
     */
    public function getForContact($contactID, $organisationIDs = [0], $limit = null)
    {
        $findQuery = "ContactID = $contactID OR (ContactID IS NULL AND OrganizationID IN (" . implode(',', $organisationIDs)
            . ")) ORDER BY CreatedTime DESC";

        if ($limit) {
            $findQuery .= " LIMIT " . $limit;
        }

        /** @var array $notifications */
        $notifications = RNCPHP\CS\Notification::find($findQuery);

        return $notifications;
    }

    /**
     * Get all the notification for a Contact on a specific category
     *
     * @param int $contactID
     * @param array $organisationIDs
     * @param $source
     * @param int|null $limit
     *
     * @return array
     */
    public function getForContactOnSource($contactID, $organisationIDs = [0], $source, $limit = null)
    {
        $findQuery = "ContactID = $contactID OR (ContactID IS NULL AND OrganizationID IN (" . implode(',', $organisationIDs)
            . ")) AND Source = '$source' ORDER BY CreatedTime DESC";

        if ($limit) {
            $findQuery .= " LIMIT " . $limit;
        }

        /** @var array $notifications */
        $notifications = RNCPHP\CS\Notification::find($findQuery);

        return $notifications;
    }

    /**
     * fetch a single notification
     *
     * @param $id
     *
     * @return object
     */
    public function fetch($id)
    {
        $notification = RNCPHP\CS\Notification::first("ID = $id");

        return $notification;
    }

    /**
     * Check if a notification is allowed to be read by the Contact
     *
     * @param int $notificationID
     * @param int $contactID
     * @param array $organisationIDs
     *
     * @return boolean
     */
    public function allowed($notificationID, $contactID, $organisationIDs = [0])
    {
        $findQuery = "ID = $notificationID AND (ContactID = $contactID OR (ContactID IS NULL AND OrganizationID IN ("
            . implode(',', $organisationIDs) . ")))";

        return count(RNCPHP\CS\Notification::find($findQuery)) > 0;
    }

    /**
     * Format specific attributes for the notification
     *
     * @param $notification
     * @param $contactNotification
     *
     * @return mixed
     */
    public function format(&$notification, $contactNotification = null) {
        $notification->createdAt = date('d F', $notification->CreatedTime);
        $notification->status = $contactNotification->ReadAt ? 'read' : 'unread';
        $notification->IconClass = $this->getIconClass($notification);
    }

    /**
     * Set the Icon Class
     *
     * @param $notification
     *
     * @return string
     */
    public function getIconClass($notification)
    {
        switch (strtolower($notification->NotificationCategory)) {
            case 'birthday':
                return 'fas fa-birthday-cake';
            break;
            case 'holiday':
            case 'vacation':
                return 'far fa-calendar-alt';
            break;
            default:
                return 'far fa-bell';
                break;
        }
    }

}