<rn:meta title="#rn:msg:SHP_TITLE_HDG#" template="creditsuisse.php" clickstream="home" login_required="true"/>

<rn:widget path="custom/dashboard/DashboardSettings"/>