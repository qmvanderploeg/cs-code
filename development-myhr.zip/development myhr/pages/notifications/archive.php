<rn:meta title="#rn:msg:SHP_TITLE_HDG#" template="creditsuisse.php" clickstream="notification_archive" login_required="true"/>

<br />
<br />
<rn:widget path="custom/notifications/ArchiveList"/>
