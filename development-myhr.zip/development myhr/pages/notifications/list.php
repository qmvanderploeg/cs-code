<rn:meta title="#rn:msg:SHP_TITLE_HDG#" template="creditsuisse.php" clickstream="notification_list" login_required="true"/>

<br />
<br />
<rn:widget path="custom/notifications/Overview"/>
