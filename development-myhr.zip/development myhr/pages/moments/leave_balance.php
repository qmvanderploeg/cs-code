<rn:meta title="#rn:msg:SHP_TITLE_HDG#" template="creditsuisse.php" clickstream="moments/leave_balance" login_required="true"/>

<div class="row">
    <div class="col-12">
        Leave Balance
    </div>
</div>
