<rn:meta title="#rn:msg:SHP_TITLE_HDG#" template="creditsuisse.php" clickstream="moments/time_tracking" login_required="true"/>

<div class="row">
    <div class="col-12">
        <h3><i class="far fa-clock"></i> <span class="px-2">Time Tracking</span></h3>
    </div>
</div>

<rn:widget path="custom/notifications/Category" source="TALT" url="/app/moments/time_tracking"/>
