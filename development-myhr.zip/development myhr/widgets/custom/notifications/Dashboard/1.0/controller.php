<?php


namespace Custom\Widgets\notifications;

use Custom\Models\Notification;
use RightNow\Models\Contact;

/**
 * Class FullList
 * @package Custom\Widgets\notifications
 */
class Dashboard extends \RightNow\Libraries\Widget\Base
{
    const LIMIT_TO_SHOW = 3;

    /** @var Notification */
    protected $model;

    /** @var Contact */
    protected $contact;

    /**
     * Dashboard constructor.
     *
     * @param $manifestAttributes
     */
    public function __construct($manifestAttributes)
    {
        parent::__construct($manifestAttributes);
        $this->CI->load->library('AutoLoad');
        $this->model = $this->CI->model('custom/Notification');
        $this->contact = $this->CI->currentcontact->current();
    }

    /**
     * Get the Dashboard Notification Items
     *
     * @return void
     */
    public function getData()
    {
        $organisationIds = $this->contact->Organization ? $this->CI->currentcontact->getOrganisationIds($this->contact->Organization): [0];

        $notificationResults = $this->model->getForContact($this->contact->ID, $organisationIds);

        $notifications = array();

        /**
         * @var Attach $key
         * @var  $notification
         */
        foreach ($notificationResults as $key => $notification) {

            $contactNotification = $this->CI->model('custom/ContactNotification')->getSingle($this->contact->ID, $notification->ID);

            // only show the none dismissed notifications
            if ($contactNotification === null || $contactNotification->DismissedAt == null) {

                $this->model->format($notification, $contactNotification);

                $notifications[] = $notification;

                // only take the limit to show
                if (count($notifications) >= self::LIMIT_TO_SHOW) {
                    break;
                }
            }

        }

        $this->data['contact'] = $this->contact;
        $this->data['notifications'] = $notifications;
    }
}