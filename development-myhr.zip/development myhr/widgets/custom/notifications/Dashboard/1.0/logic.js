RightNow.namespace('Custom.Widgets.notifications.Dashboard');
Custom.Widgets.notifications.Dashboard = RightNow.Widgets.extend({

    /**
     * Constructor
     */
    constructor: function() {

    },

});