<div class="my-2">
    <div class="row">
        <div class="col-12 col-md-6">
            <div class="d-flex align-items-center">
                <div class="row">
                    <div class="col-6"></div>
                </div>
                <div onclick="window.location.href='app/notifications/list/reset/1'"><i class="far fa-bell fa-3x"></i></div>
                <h3 class="ml-3">Notifications Archive</h3>
            </div>
        </div>
        <div class="col-12 col-md-6">
            <div class="float-right">
                <a class="text-secondary" href="/app/notifications/list"><i class="fas fa-bell"></i> List </a>
            </div>
        </div>
    </div>
    <? if (count($this->data['notifications'])): ?>
    <div class="row my-3">
        <div class="col-12 col-md-6">
            <table class="table table-hover notification-list">
                <thead>
                <th class="col-icon" scope="col"></th>
                <th class="col-date" scope="col">Received</th>
                <th class="col-description" scope="col">Description</th>
                <th class="col-" scope="col">From</th>
                </thead>
                <tbody>
                <?php foreach ($this->data['notifications'] as $notification): ?>
                <tr
                  class="
                    notification-item
                    <?= $notification->status; ?>
                    <?= $notification->ID === $this->data['activeNotification']->ID ? 'active': '' ?>"
                        onclick="window.location.href='app/notifications/list/show/<?= $notification->ID ?>'">
                    <td><i class="far <?= $notification->status === 'read' ? 'fa-envelope-open': 'fa-envelope' ?>"></i></td>
                    <td><?= $notification->createdAt; ?></td>
                    <td><?= $notification->Title; ?></td>
                    <td><?= $notification->CreatedByAccount->LookupName ?: 'Unknown'; ?></td>
                </tr>
                <?php endforeach; ?>

                </tbody>
            </table>
        </div>
        <div class="col-12 col-md-6 notification-detail">
            <div class="notification-detail-header">
                <div class="row border-bottom">
                    <div class="col-10 float-left">
                        <h4><?= $this->data['activeNotification']->Title ?></h4>
                        <p class="text-secondary" style="font-size: 0.8em">
                            <span class="border-right px-1"><?= $this->data['activeNotification']->createdAt ?></span>
                            <span class="px-1"><?= $this->data['activeNotification']->CreatedByAccount->LookupName?></span>
                        </p>
                    </div>
                    <div class="col-2 float-left">
                        <i class="far fa-envelope fa-3x"></i>
                    </div>
                </div>

            </div>
            <div class="notification-detail-body">
                <div class="col-12">
                    <p>
                        <?= $this->data['activeNotification']->Text ?>
                    </p>
                    <? if ($this->data['activeNotification']->Url): ?>
                        <p>
                            <a class="text-secondary" href="<?= $this->data['activeNotification']->Url ?>" target="_blank">
                                <i class="fas fa-external-link-alt 2x"></i> <span>GO TO</span>
                            </a>
                        </p>

                    <? endif; ?>
                </div>
                <div class="col-12 text-right">
                    <a class="text-secondary" href="/app/notifications/archive/restore/<?= $this->data['activeNotification']->ID ?>">
                        <i class="far fa-trash-alt"></i> <span>Restore</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <? endif; ?>
    <? if (empty($this->data['notifications'])): ?>
        <div class="row my-3">
            <div class="col-12 px-3">
                <h5>There are not notification is the archive list</h5>
            </div>

        </div>
    <? endif; ?>
</div>
