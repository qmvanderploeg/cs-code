RightNow.namespace('Custom.Widgets.notifications.ArchiveList');
Custom.Widgets.notifications.ArchiveList = RightNow.Widgets.extend({

    /**
     * Constructor
     */
    constructor: function() {

    },

});