RightNow.namespace('Custom.Widgets.notifications.Overview');
Custom.Widgets.notifications.Overview = RightNow.Widgets.extend({

    /**
     * Constructor
     */
    constructor: function() {

        var self = this;

        $("#notification-list .notification-item").click(function () {
            var elem = $(this);
            self.showNotificationDetail(elem.data('id'));
        });
        
        $("#dismiss-notification").click(function () {
            
        });
    },

    /**
     * Show the notification details
     * @param id
     */
    showNotificationDetail: function(id) {
        this.markAsRead(id);
        $(".notification-detail.visible").removeClass('visible').addClass('d-none');
        $("#notfication-detail-" + id).removeClass('d-none').addClass('visible');
        $(".notification-item.active").removeClass('active');
        $("#notification-" + id).addClass('active');
    },

    /**
     * Mark the notfication as read through Rest Ajax Call
     * @param id
     */
    markAsRead: function (id) {
        var eventObj = new RightNow.Event.EventObject(
            this,
            {data: {id: id }}
        );

        RightNow.Ajax.makeRequest(this.data.attrs.mark_notification_read_ajax_endpoint, eventObj.data, {
            successHandler: function (response) {
                if (response.success) {
                    $("#notification-" + id + ".unread").removeClass('unread').addClass('read');
                }

                console.warn('response', response)
            },
            scope: this,
            data: eventObj,
            json: true,
        });
    },





});