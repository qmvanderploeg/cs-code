<div class="my-2">
    <div class="row">
        <div class="col-12 col-md-6">
            <div class="d-flex align-items-center">
                <div class="row">
                    <div class="col-6"></div>
                </div>
                <div onclick="window.location.href='app/notifications/list/reset/1'"><i class="far fa-bell fa-3x"></i></div>
                <h3 class="ml-3">Notifications</h3>
            </div>
        </div>
        <div class="col-12 col-md-6">
            <div class="float-right">
                <a class="text-secondary" href="/app/notifications/archive"><i class="fas fa-archive"></i> Archive </a>
            </div>
        </div>
    </div>
    <? if (count($this->data['notifications'])): ?>
    <div class="row my-3">
        <div class="col-12 col-md-6">
            <table id="notification-list" class="table table-hover notification-list">
                <thead>
                <th class="col-icon" scope="col"></th>
                <th class="col-date" scope="col">Received</th>
                <th class="col-description" scope="col">Description</th>
                <th class="col-" scope="col">From</th>
                </thead>
                <tbody>
                <?php foreach ($this->data['notifications'] as $notification): ?>
                <tr
                  id="notification-<?= $notification->ID ?>"
                  class="
                    notification-item
                    <?= $notification->status; ?>
                    <?= $notification->ID === $this->data['activeNotification']->ID ? 'active': '' ?>" data-id="<?= $notification->ID ?>"
                >
                    <td><i class="<?= $notification->IconClass ?>"></i></td>
                    <td><?= $notification->createdAt; ?></td>
                    <td><?= $notification->Title; ?></td>
                    <td><?= $notification->CreatedByAccount->LookupName ?: 'Unknown'; ?></td>
                </tr>
                <?php endforeach; ?>

                </tbody>
            </table>
        </div>
        <? foreach ($this->data['notifications'] as $notification): ?>
            <div
              id="notfication-detail-<?= $notification->ID ?>"
              class="col-12 col-md-6 notification-detail <?= $notification->ID !== $this->data['activeNotification']->ID ? 'd-none': 'visible' ?>"
            >
                <div class="notification-detail-header">
                    <div class="row border-bottom">
                        <div class="col-10 float-left">
                            <h4 id="title"><?= $notification->Title ?></h4>
                            <p class="text-secondary" style="font-size: 0.8em">
                                <span id="date" class="border-right px-1"><?= $notification->createdAt ?></span>
                                <span id="lookUpName" class="px-1"><?= $notification->CreatedByAccount->LookupName?></span>
                            </p>
                        </div>
                        <div class="col-2 float-left">
                            <i id="iconClass" class="<?= $notification->IconClass ?> fa-3x"></i>
                        </div>
                    </div>

                </div>
                <div class="notification-detail-body">
                    <div class="col-12">
                        <p id="description">
                            <?= $notification->Text ?>
                        </p>
                            <p>
                                <a
                                  class="text-secondary <?= $notification->Url ? '' : 'd-none'?>"
                                  href="<?= $notification->Url ?>"
                                  target="_blank"
                                >
                                    <i class="fas fa-external-link-alt 2x"></i> <span>GO TO</span>
                                </a>
                            </p>
                    </div>
                    <div class="col-12 text-right">
                        <div id="dismiss-notification" class="text-secondary" data-id="<?= $notification->ID ?>">
                            <i class="far fa-trash-alt"></i> <span>Dismiss</span>
                        </div>
                    </div>
                </div>
            </div>
        <? endforeach; ?>
    </div>
    <? endif; ?>
</div>