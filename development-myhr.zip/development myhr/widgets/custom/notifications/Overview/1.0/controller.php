<?php

namespace Custom\Widgets\notifications;

use Custom\Models\ContactNotification;
use Custom\Models\Notification;
use RightNow\Models\Contact;

/**
 * Class Overview
 * @package Custom\Widgets\notifications
 */
class Overview extends \RightNow\Libraries\Widget\Base
{
    /**
     * @var Notification $model
     */
    protected $notificationModel;

    /**
     * @var ContactNotification $contactNotificationModel
     */
    protected $contactNotificationModel;

    /**
     * @var Contact $contact
     */
    protected $contact;

    /**
     * FullList constructor.
     *
     * @param $attrs
     */
    public function __construct($attrs)
    {
        parent::__construct($attrs);

        $this->CI->load->library('AutoLoad');
        $this->notificationModel = $this->CI->model('custom/Notification');
        $this->contactNotificationModel = $this->CI->model('custom/ContactNotification');
        $this->contact = $this->CI->currentcontact->current();

        $this->setAjaxHandlers([
            'mark_notification_read_ajax_endpoint' => [
                'method' => 'postMarkNotificationAsRead',
                'clickstream' => 'custom_mark_notification_read_ajax_endpoint',
            ],
        ]);
    }

    /**
     * Get the Notification Items
     *
     * @return void
     */
    public function getData()
    {
        $organisationIds = $this->contact->Organization ? $this->CI->currentcontact->getOrganisationIds($this->contact->Organization): [0];

        $notifications = $this->notificationModel->getForContact($this->contact->ID, $organisationIds);

        // show active Notification
        if ($showID = getUrlParm('show')) {

            // check if active notification is allow
            if ($this->notificationModel->allowed($showID, $this->contact->ID, $organisationIds)) {
                $activeNotification = $this->notificationModel->fetch($showID);

                // mark notification as read
                $contactNotification = $this->contactNotificationModel->findOrNew($this->contact->ID, $activeNotification->ID);
                $contactNotification->ReadAt = time();
                $contactNotification->save();
            }
        }

        if ($dismissID = getUrlParm('dismiss')) {

            $dismissedNotification = $this->notificationModel->fetch($dismissID);

            // check if active notification is allow
            if ($this->notificationModel->allowed($dismissedNotification->ID, $this->contact->ID, $organisationIds)) {

                // mark notification as dismissed
                $contactNotification = $this->contactNotificationModel->findOrNew($this->contact->ID, $dismissedNotification->ID);
                $contactNotification->DismissedAt = time();
                $contactNotification->save();
            }
        }



        if (getUrlParm('reset')) {
            foreach ($notifications as $key => &$notification) {
                $this->contactNotificationModel->remove($this->contact->ID, $notification->ID);
            }
        }

        // attach all $contactNotification to
        foreach ($notifications as $key => &$notification) {

            $contactNotification = $this->CI->model('custom/ContactNotification')->getSingle($this->contact->ID, $notification->ID);

            /** Remove all notification that are dismissed */
            if ($contactNotification->DismissedAt !== null) {
                unset($notifications[$key]);
                continue;
            }

            $this->notificationModel->format($notification, $contactNotification);

        }

        if (!isset($activeNotification)) {
            $activeNotification = $this->CI->arr->first($notifications);
        }

        $this->data['notifications'] = $notifications;
        $this->data['activeNotification'] = $activeNotification;

    }

    /**
     * Get a Notification on ID
     *
     * @param $params
     */
    public function postMarkNotificationAsRead($params)
    {
        $id = (int) json_decode($params['id']);

        $organisationIds = $this->contact->Organization ? $this->CI->currentcontact->getOrganisationIds($this->contact->Organization): [0];

        $result = false;

        // check if active notification is allow
        if ($this->notificationModel->allowed($id, $this->contact->ID, $organisationIds)) {

            // mark notification as read
            $contactNotification = $this->contactNotificationModel->findOrNew($this->contact->ID, $id);
            $contactNotification->ReadAt = time();
            $contactNotification->save();

            $result = true;
        }

        echo json_encode(['success' => $result]);
    }
}