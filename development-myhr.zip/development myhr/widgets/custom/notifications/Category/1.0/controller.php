<?php

namespace Custom\Widgets\notifications;

use Custom\Models\ContactNotification;
use Custom\Models\Notification;
use RightNow\Models\Contact;

/**
 * Class Category
 * @package Custom\Widgets\notifications
 */
class Category extends \RightNow\Libraries\Widget\Base
{
    /**
     * @var Notification $notificationModel
     */
    protected $notificationModel;

    /**
     * @var ContactNotification $contactNotificationModel
     */
    protected $contactNotificationModel;

    /**
     * @var Contact $contact
     */
    protected $contact;

    /**
     * FullList constructor.
     *
     * @param $attrs
     */
    public function __construct($attrs)
    {
        parent::__construct($attrs);

        $this->CI->load->library('AutoLoad');
        $this->notificationModel = $this->CI->model('custom/Notification');
        $this->contactNotificationModel = $this->CI->model('custom/ContactNotification');
        $this->contact = $this->CI->currentcontact->current();
    }

    /**
     * Get the Notification Items
     *
     * @return void
     */
    public function getData()
    {
        $source = $this->attrs['source']->value;
        $this->data['url'] = $this->attrs['url']->value;

        $organisationIds = $this->contact->Organization ? $this->CI->currentcontact->getOrganisationIds($this->contact->Organization): [0];

        $notifications = $this->notificationModel->getForContactOnSource($this->contact->ID, $organisationIds, $source);

        // show active Notification
        if ($showID = getUrlParm('show')) {

            // check if active notification is allow
            if ($this->notificationModel->allowed($showID, $this->contact->ID, $organisationIds)) {
                $activeNotification = $this->notificationModel->fetch($showID);

                // mark notification as read
                $contactNotification = $this->CI->model('custom/ContactNotification')->findOrNew($this->contact->ID, $activeNotification->ID);
                $contactNotification->ReadAt = time();
                $contactNotification->save();
            }
        }

        if ($dismissID = getUrlParm('dismiss')) {

            $dismissedNotification = $this->notificationModel->fetch($dismissID);

            // check if active notification is allow
            if ($this->notificationModel->allowed($dismissedNotification->ID, $this->contact->ID, $organisationIds)) {

                // mark notification as dismissed
                $contactNotification = $this->CI->model('custom/ContactNotification')->findOrNew($this->contact->ID, $dismissedNotification->ID);
                $contactNotification->DismissedAt = time();
                $contactNotification->save();
            }
        }



        if (getUrlParm('reset')) {
            foreach ($notifications as $key => &$notification) {
                $this->CI->model('custom/ContactNotification')->remove($this->contact->ID, $notification->ID);
            }
        }

        // attach all $contactNotification to
        foreach ($notifications as $key => &$notification) {

            $contactNotification = $this->CI->model('custom/ContactNotification')->getSingle($this->contact->ID, $notification->ID);

            /** Remove all notification that are dismissed */
            if ($contactNotification->DismissedAt !== null) {
                unset($notifications[$key]);
                continue;
            }

            $this->notificationModel->format($notification, $contactNotification);

        }

        if (!isset($activeNotification)) {
            $activeNotification = $this->CI->arr->first($notifications);
        }

        $this->data['notifications'] = $notifications;
        $this->data['activeNotification'] = $activeNotification;

    }
}