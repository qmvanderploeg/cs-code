RightNow.namespace('Custom.Widgets.notifications.Category');
Custom.Widgets.notifications.Category = RightNow.Widgets.extend({

    /**
     * Constructor
     */
    constructor: function() {

    },

});