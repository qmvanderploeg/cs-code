<?php

namespace Custom\Widgets\mylinks;

use Custom\Models\MyLink;
use RightNow\Models\Contact;
use \RightNow\Libraries\Widget\Base;

/**
 * Class MyLinksSettings
 * @package Custom\Widgets\mylinks
 */
class Overview extends Base
{
    /**
     * @var MyLink $myLinkModel
     */
    protected $myLinkModel;

    /**
     * @var Contact $contact
     */
    protected $contact;

    /**
     * MyLinksSettings constructor.
     *
     * @param $manifestAttributes
     */
    public function __construct($manifestAttributes)
    {
        parent::__construct($manifestAttributes);

        $this->CI->load->library('AutoLoad');
        $this->myLinkModel = $this->CI->model('custom/MyLink');
        $this->contact = $this->CI->currentcontact->current();

        $this->setAjaxHandlers([
            'save_item_ajax_endpoint' => [
                'method' => 'postSaveItem',
                'clickstream' => 'custom_save_item_action',
            ],
            'save_ordering_ajax_endpoint' => [
                'method' => 'postSaveOrdering',
                'clickstream' => 'custom_save_ordering_action',
            ],
            'delete_item_ajax_endpoint' => [
                'method' => 'postDeleteItem',
                'clickstream' => 'custom_delete_item_action',
            ],
        ]);
    }

    /**
     * Get the Data
     *
     * @return void
     */
    public function getData()
    {

        $actionMode = getUrlParm('mode') === 'edit' ? 'edit' : 'view';


        $title = $_POST['title'];
        $url = $_POST['url'];
        $iconClass = $_POST['iconClass'];
        $ordering = null;

        if ($_POST['action'] === 'save') {
            $ID = (int) $_POST['linkID'];

            if ($ID == 0) {
                $otherLinks = $this->myLinkModel->getForContact($this->contact->ID, 0);
                $lastItem = end($otherLinks);
                $ordering = $lastItem ? $lastItem->Ordering + 1 : 1;

            }

            $link = $this->myLinkModel->updateOrCreate($ID, $this->contact->ID, $title, $url, $iconClass, $ordering);

            header('Location: /app/mylinks/mode/edit');

        }

        $favoriteLinks = $this->myLinkModel->getForContact($this->contact->ID, 1);

        // refresh other links
        $otherLinks = $this->myLinkModel->getForContact($this->contact->ID, 0);


        $this->data['actionMode'] = $actionMode;
        $this->data['favoriteLinks'] = $favoriteLinks;
        $this->data['otherLinks'] = $otherLinks;
        $this->data['availableIcons'] = $this->getAvailableIconClasses();
    }

    /**
     * Handles saving the item send by AJAX
     *
     * @param $params
     *
     * @return string
     */
    public function postSaveItem($params) {
        $item = json_decode($params['item']);

        $linkID = $item->id !== "" ? (int) $item->id : 0;
        $ordering = null;

        if ($linkID == 0) {
            $otherLinks = $this->myLinkModel->getForContact($this->contact->ID, 0);
            $lastItem = end($otherLinks);
            $ordering = $lastItem ? $lastItem->Ordering + 1 : 1;
        }

        $result = $this->myLinkModel->updateOrCreate($linkID, $this->contact->ID, $item->title, $item->url, $item->iconClass, $ordering);
        unset($result->ContactID);

        $data['result'] = $result;

        echo json_encode($data);
    }

    /**
     * Handles saving the order for a type of links
     *
     * @param $params
     *
     * @return string
     */
    public function postSaveOrdering($params) {

        $data = json_decode($params['data']);

        if ($data->type === 'favorites') {
            $this->updateFavoriteSelection($data->ids);
        }

        if ($data->type === 'others') {
            $this->updateOtherSelection($data->ids);
        }



        echo json_encode(['result' => $data]);

    }

    /**
     * Handles deleting the item send by AJAX
     *
     * @param $params
     *
     * @return string
     */
    public function postDeleteItem($params) {
        $item = json_decode($params['item']);

        $data = new \stdClass();

        $result = $this->myLinkModel->remove($item->id, $this->contact->ID);

        echo json_encode(['success' => $result]);
    }

    /**
     * Update the Favorites selection
     *
     * @param $favoritesInput
     *
     * @return void
     */
    private function updateFavoriteSelection($favoritesInput)
    {
        $favoriteLinkIDS = $favoritesInput != "" ? explode(',', $favoritesInput): [];

        $oldFavoriteLinks = $this->myLinkModel->getForContact($this->contact->ID, 1);

        foreach ($oldFavoriteLinks as $oldFavoriteLink) {
            $oldFavoriteLink->Favorite = 0;
            $oldFavoriteLink->save();
        }

        foreach ($favoriteLinkIDS as $key => $favoriteLinkID) {
            $this->myLinkModel->saveAsFavorite($favoriteLinkID, $this->contact->ID, $key+1);
        }
    }

    /**
     * Update the Other Selection
     *
     * @param $othersInput
     *
     * @return void
     */
    private function updateOtherSelection($othersInput)
    {
        $otherLinkIDS = $othersInput != "" ? explode(',', $othersInput): [];

        foreach ($otherLinkIDS as $key => $otherLinkID) {
            $this->myLinkModel->saveOrdering($otherLinkID, $this->contact->ID, $key+1);
        }
    }

    /**
     * Get available icons
     *
     * @return array
     */
    private function getAvailableIconClasses()
    {
        return [
            'fas fa-user',
            'far fa-smile',
            'fas fa-link',
            'far fa-heart',
        ];
    }

}