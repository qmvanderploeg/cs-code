RightNow.namespace('Custom.Widgets.mylinks.Overview');
Custom.Widgets.mylinks.Overview = RightNow.Widgets.extend({

    /**
     * Constructor
     */
    constructor: function() {

        var self = this;

        this.editMode = false;

        this.init();

        $("#new-link").click(function (event)  {
            self.openForm(null);
        });

        $("#link-form .close").click(function (event) {
            self.closeForm();
        });

        $("#link-form .bg-blur").click(function (event) {
            self.closeForm();
        });

        $("#link-form .cancel").click(function (event) {
            self.closeForm();
        });

        $(".edit-link").click(function (event) {
            var elem = $(this);

           self.openForm(elem);
        });

        $("#saveLinkBtn").click(function (event) {
            self.save_item_ajax_endpoint();
        });

        $(".remove-link").click(function (event) {
            var elem = $(this);
            self.delete_item_ajax_endpoint(elem);
        });

        $("#toggle-mode").click(function (event) {
            self.toggleEditMode();
        });

        $('.select-icon-item').click(function (event) {
            var elem = $(this);
            self.selectIcon(elem);
        });

        $("#otherLinks").sortable({
            items: '.link-item',
            cancel: '.link-item.sortable-disabled',
            connectWith: "#favoriteLinks",
            placeholder: 'placeholder-item',
            stop: function (event, ui) {

                self.updateOtherSelection();

            },
            receive: function (event , ui) {
                self.updateOtherSelection();
            },

        }).disableSelection();

        $("#favoriteLinks").sortable({
            items: '.link-item',
            cancel: '.link-item.sortable-disabled',
            connectWith: "#otherLinks",
            placeholder: 'placeholder-item',
            stop: function (event, ui) {
                self.updateFavoriteSelection();
            },
            receive: function (event, ui) {
                if ($("#favoriteLinks .link-item").length > 6 ) {
                    console.log('got to many ', $("#favoriteLinks .link-item").length);
                    $(ui.sender).sortable('cancel');
                } else {
                    self.updateFavoriteSelection();
                }

            },
            over: function (event, ui) {
                console.error('got over');
                if ($("#favoriteLinks .link-item").length > 6 ) {
                    console.log('got to many ', $("#favoriteLinks .link-item").length);
                    $(ui.sender).sortable('cancel');
                }

            }
        }).disableSelection();

    },

    init: function () {
        var favorites = [];
        $("#favoriteLinks .link-item").each(function(i, el) {
            favorites.push($(this).data('id'));
        });

        $('#favorites-selection').val(favorites.toString());

        var others = [];
        $("#otherLinks .link-item").each(function(i, el) {
            others.push($(this).data('id'));
        });

        $('#others-selection').val(others.toString());
    },

    /**
     * Toggle Between the view and edit mode
     *
     * @return void
     */
    toggleEditMode: function() {
        this.editMode = !this.editMode;

        if (this.editMode) {
            $("#toggle-mode .btn-view-mode").show();
            $("#toggle-mode .btn-edit-mode").hide();

            $(".link-actions").each(function (i, el) {
                $(this).show();
            });

            $(".link-item").removeClass('sortable-disabled');
            $(".link-item .link").toggle();
            $(".link-item .preview").toggle();

        } else {
            $("#toggle-mode .btn-view-mode").hide();
            $("#toggle-mode .btn-edit-mode").show();


            $(".link-actions").each(function (i, el) {
                $(this).hide();
            });

            $(".link-item").addClass('sortable-disabled');
            $(".link-item .link").toggle();
            $(".link-item .preview").toggle();
        }
    },

    /**
     * Send the data to the controller to save the item
     */
    save_item_ajax_endpoint: function() {

        var item = {
            id: $("#link-form #linkID").val(),
            title: $("#link-form #title").val(),
            url: $("#link-form #url").val(),
            iconClass: 'fas fa-user',
        };

        var eventObj = new RightNow.Event.EventObject(
            this,
            {data: {item: JSON.stringify(item)}}
        );

        RightNow.Ajax.makeRequest(this.data.attrs.save_item_ajax_endpoint, eventObj.data, {
            successHandler: this.saveItemCallback,
            scope: this,
            data: eventObj,
            json: true,
        });
    },

    saveItemCallback: function(response) {
        console.log('response', response);


    },

    /**
     * Send new ordering to the controller to save the ordering
     *
     * @param type
     *
     * @return void
     */
    save_ordering_ajax_endpoint: function(type, ids) {
        var item = {
            type: type,
            ids: ids,
        };

        console.log(item);

        var eventObj = new RightNow.Event.EventObject(
            this,
            {data: {data: JSON.stringify(item) }}
        );

        RightNow.Ajax.makeRequest(this.data.attrs.save_ordering_ajax_endpoint, eventObj.data, {
            successHandler: function (response) {
                console.warn('response', response);
            },
            scope: this,
            data: eventObj,
            json: true,
        });
    },

    /**
     * Send the data to the controller to save the item
     *
     * @return void
     */
    delete_item_ajax_endpoint: function(elem) {

        var item = {
            id: elem.data('id'),
        };

        var eventObj = new RightNow.Event.EventObject(
            this,
            {data: {item: JSON.stringify(item) }}
        );

        RightNow.Ajax.makeRequest(this.data.attrs.delete_item_ajax_endpoint, eventObj.data, {
            successHandler: function (response) {
                if (response.success) {
                    $("#link-" + elem.data('id')).remove();
                }
            },
            scope: this,
            data: eventObj,
            json: true,
        });
    },

    /**
     * Update the Others Selection
     *
     * @return void
     */
    updateOtherSelection: function () {
        var others = [];
        $("#otherLinks .link-item").each(function(i, el) {
            others.push($(this).data('id'));
        });

        $('#others-selection').val(others.toString());
        this.save_ordering_ajax_endpoint('others', others.toString());
    },

    /**
     * Update the Favorites Selection
     *
     * @return void
     */
    updateFavoriteSelection: function () {
        var favorites = [];
        $("#favoriteLinks .link-item").each(function(i, el) {
            favorites.push($(this).data('id'));
        });

        $('#favorites-selection').val(favorites.toString());
        this.save_ordering_ajax_endpoint('favorites', favorites.toString());
    },

    /**
     * Open the form and set the data if link exist
     *
     * @param elem
     *
     * @return void
     */
    openForm: function (elem) {
        if (elem !== null) {
            $("#link-form #linkID").val(elem.data('id'));
            $("#link-form #title").val(elem.data('title'));
            $("#link-form #url").val(elem.data('url'));
            $("#link-form .select-icon-item").each(function () {
                var child = $(this);
                if (child.data('icon') === elem.data('icon_class')) {
                    child.addClass('selected');
                    $('#selectedIcon').val(elem.data('icon_class'));
                }
            });
        } else {

            var iconElem = $("#link-form .select-icon-item").first();

            iconElem.addClass('selected');
            this.selectIcon(iconElem);
        }

        $("#link-form").show();
    },

    /**
     * Select Icon
     *
     * @return void
     */
    selectIcon: function(element) {

        $('input[name=iconClass]').val(element.data('icon'));

        $('.select-icon-item').removeClass('selected');
        element.addClass('selected');
    },

    /**
     * Clear the form and hide the form
     *
     * @return void
     */
    closeForm: function () {
        $("#link-form").hide();
        $("#link-form #linkID").val('');
        $("#link-form #title").val('');
        $("#link-form #url").val('');
        $("#link-form .select-icon-item.selected").removeClass('selected');
    }

});