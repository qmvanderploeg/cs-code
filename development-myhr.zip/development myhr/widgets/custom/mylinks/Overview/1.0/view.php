<form action="/app/mylinks/save/selection/1" method="POST">
    <div class="row">
        <div class="col-6">
            <h3>My Links</h3>
        </div>
        <div id="actions" class="col-6">
            <input id="action-mode" type="hidden" name="action-mode" value="<?= $this->data['actionMode'] ?>" >
            <div id="toggle-mode" class="float-right btn btn-secondary-outline">
                <div class="btn-edit-mode">
                    <i class="fas fa-pencil-alt" style="font-size: 1.5em"></i>
                </div>
                <div class="btn-view-mode">
                    <i class="far fa-times-circle" style="font-size: 1.5em"></i>
                </div>
            </div>

        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <h4>Favorites</h4>
        </div>
    </div>
    <div id="favoriteLinks" class="row favoriteLinks p-2">

        <? foreach ($this->data['favoriteLinks'] as $favoriteLink): ?>
            <div id="link-<?= $favoriteLink->ID ?>" class="col-4 col-lg-2 link-item sortable-disabled" data-id="<?= $favoriteLink->ID ?>">
                <div class="m-1 py-4">
                    <div class="text-center">
                        <div class="preview text-secondary">
                            <i class="<?= $favoriteLink->IconClass ?> fa-2x"></i>
                            <p><?= $favoriteLink->Title ?> </p>
                        </div>
                        <a class="link text-secondary" href="<?= $favoriteLink->Url ?>" target="_blank">
                            <i class="<?= $favoriteLink->IconClass ?> fa-2x"></i>
                            <p><?= $favoriteLink->Title ?> </p>
                        </a>
                    </div>
                    <div class="link-actions">
                        <div class="btn-group d-flex justify-content-center">
                            <div class="btn">
                                <div class="remove-link" data-id="<?= $favoriteLink->ID ?>">
                                    <i class="far fa-trash-alt"></i>
                                </div>
                            </div>
                            <div class="btn">
                                <div
                                  class="edit-link text-right"
                                  data-id="<?= $favoriteLink->ID ?>"
                                  data-title="<?= $favoriteLink->Title ?>"
                                  data-url="<?= $favoriteLink->Url ?>"
                                  data-icon_class="<?= $favoriteLink->IconClass ?>"
                                >
                                    <i class="fas fa-pencil-alt small"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <? endforeach; ?>

    </div>

    <input id="favorites-selection" name="favorites-selection" type="hidden" name="favoriteLinks" value="" />

    <hr />

    <div class="row">
        <div class="col-12">
            <h4>Others</h4>
        </div>
    </div>
    <div id="otherLinks" class="row otherLinks p-2">

        <? foreach ($this->data['otherLinks'] as $otherLink): ?>
        <div id="link-<?= $otherLink->ID ?>" class="col-4 col-lg-2 link-item sortable-disabled" data-id="<?= $otherLink->ID ?>">
            <div class="m-1 py-4">
                <div class="text-center">
                    <div class="preview text-secondary">
                        <i class="<?= $otherLink->IconClass ?> fa-2x"></i>
                        <p><?= $otherLink->Title ?></p>
                    </div>
                    <a class="link text-secondary" href="<?= $otherLink->Url ?>" target="_blank">
                        <i class="<?= $otherLink->IconClass ?> fa-2x"></i>
                        <p><?= $otherLink->Title ?> </p>
                    </a>
                </div>
                <div class="link-actions">
                    <div class="btn-group d-flex justify-content-center">
                        <div class="btn">
                            <div class="remove-link" data-id="<?= $otherLink->ID ?>">
                                <i class="far fa-trash-alt"></i>
                            </div>

                        </div>
                        <div class="btn">
                            <div
                              class="edit-link text-right"
                              data-id="<?= $otherLink->ID ?>"
                              data-title="<?= $otherLink->Title ?>"
                              data-url="<?= $otherLink->Url ?>"
                              data-icon_class="<?= $otherLink->IconClass ?>"
                            >
                                <i class="fas fa-pencil-alt small"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <? endforeach; ?>
        <div class="col-4 col-lg-2 new-link text-center">
            <div class="m-1 my-4">
                <div id="new-link" class="text-secondary">
                    <i class="far fa-plus-square fa-2x"></i>
                    <p>New</p>
                </div>
            </div>
        </div>
    </div>

    <input id="others-selection"  name="others-selection" type="hidden" name="otherLinks" />

</form>
<div id="link-form" class="link-form">
    <div class="bg-blur"></div>
    <div class="box shadow-lg p-3 mb-5 bg-white">
        <div class="close"><i class="far fa-times-circle"></i></div>
        <div class="row my-2">
            <div class="col-12">
                <form action="/app/mylinks" method="POST">
                <div>
                    <input type="hidden" name="action" value="save">
                    <input id="linkID" type="hidden" name="linkID" value="">
                </div>
                <div class="form-row">
                    <div class="form-group col-12 col-md-6">
                        <input id="title" class="form-control" type="text" name="title" placeholder="Title" value="">
                    </div>
                    <div class="form-group col-12 col-md-6">
                        <input id="url" class="form-control" type="text"  name="url" placeholder="Url" value="">
                    </div>
                </div>
                <div class="form-row">
                    <div id="icons" class="form-group col-12">
                        <? foreach ($this->data['availableIcons'] as $icon): ?>
                            <div id="<?= $icon ?>" class="select-icon-item float-left" data-icon="<?= $icon ?>">
                                <i class="p-2 <?= $icon ?> fa-2x"></i>
                            </div>
                        <? endforeach; ?>
                        <input id="selectedIcon" type="hidden" name="iconClass" value="" />
                    </div>

                </div>
                <hr />
                <div class="">
                    <div class="btn btn-outline-secondary cancel">Cancel</div>
                    <button type="submit" class="btn btn-secondary save float-right">Save</button>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>

<br /><br /><br />
