<?php

namespace Custom\Widgets\mylinks;

use Custom\Models\MyLink;
use RightNow\Models\Contact;
use \RightNow\Libraries\Widget\Base;

/**
 * Class MyLinksSettings
 * @package Custom\Widgets\mylinks
 */
class MyLinksSettings extends Base
{
    /**
     * @var MyLink $myLinkModel
     */
    protected $myLinkModel;

    /**
     * @var Contact $contact
     */
    protected $contact;

    /**
     * MyLinksSettings constructor.
     *
     * @param $manifestAttributes
     */
    public function __construct($manifestAttributes)
    {
        parent::__construct($manifestAttributes);

        $this->CI->load->library('AutoLoad');
        $this->myLinkModel = $this->CI->model('custom/MyLink');
        $this->contact = $this->CI->currentcontact->current();
    }

    /**
     * Get Data
     *
     * @return void
     */
    public function getData()
    {
        // check if we need to save a link
        if ($linkID = getUrlParm('save')) {

            if ($linkID == 'new') {
                $linkID = 0;
            }

            $title = $_POST['title'];
            $url = $_POST['url'];
            $ordering = $_POST['ordering'];
            $iconClass = $_POST['iconClass'];

            $this->myLinkModel->updateOrCreate($linkID, $this->contact->ID, $title, $url, $iconClass, $ordering);

            header('Location: /app/settings/mylinks');
        }

        // check if we need to delete a link
        if ($linkID = getUrlParm('delete')) {
            $this->myLinkModel->remove($linkID, $this->contact->ID);
            header('Location: /app/settings/mylinks');
        }

        // check if there is a link to edit
        if ($linkID = getUrlParm('edit')) {
            $this->data['editLink'] = $this->myLinkModel->getSingle($linkID, $this->contact->ID);
        }

        $myLinks = $this->myLinkModel->getForContact($this->contact->ID);

        $this->data['new'] = getUrlParm('new');
        $this->data['myLinks'] = $myLinks;
        $this->data['availableIcons'] = $this->getAvailableIconClasses();
    }

    /**
     * Get available icons
     *
     * @return array
     */
    private function getAvailableIconClasses()
    {
        return [
            'fas fa-user',
            'far fa-smile',
            'fas fa-link',
            'far fa-heart',
        ];
    }

}