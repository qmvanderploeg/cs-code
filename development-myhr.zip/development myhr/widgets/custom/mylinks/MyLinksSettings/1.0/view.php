<div class="row my-3">
    <div class="col-11">
        <h3>MyLinks Settings</h3>
    </div>
    <div class="col-1">
        <div class="btn btn-outline-secondary" onclick="window.location.href='app/settings/mylinks/new/1'">New</div>
    </div>

</div>
<? if ($this->data['new']): ?>
    <div class="row m-2">
        <div class="col-12">
            <div class="border border-secondary border-1 rounded p-5">
                <form id="new-link" action="/app/settings/mylinks/save/new" method="POST">
                    <div class="form-row">
                        <div class="form-group col-12 col-md-6">
                            <label for="title">Title</label>
                            <input class="form-control" type="text" name="title" placeholder="Title" value="">
                        </div>
                        <div class="form-group col-12 col-md-6">
                            <label for="url">Url</label>
                            <input class="form-control" type="text"  name="url" placeholder="Url" value="">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-6 col-md-3">
                            <label>Order</label>
                            <select class="form-control" name="ordering">
                                <? foreach (range(1, 5) as $number ): ?>
                                    <option value="<?= $number ?>"><?= $number ?></option>
                                <? endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-12">
                            <? foreach ($this->data['availableIcons'] as $icon): ?>
                                <div class="select-icon-item float-left" data-icon="<?= $icon ?>">
                                    <i class="p-2 <?= $icon ?> fa-2x" ></i>
                                </div>
                            <? endforeach; ?>
                            <input id="selectedIcon" type="hidden" name="iconClass" value="" />
                        </div>

                    </div>
                    <div class="form-group">
                        <div
                          class="float-left btn btn-outline-secondary text-secondary"
                          onclick="window.location.href='/app/settings/mylinks'">
                            Cancel
                        </div>
                        <button type="submit" class="float-right btn btn-secondary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<? endif; ?>
<? if($this->data['editLink']): ?>
    <div class="m-2 mb-5">
        <div class="border border-secondary border-1 rounded">
            <div class="row">
                <div class="col-12">
                    <div
                      class="float-right btn btn-outline-secondary text-secondary border-0"
                      onclick="window.location.href='/app/settings/mylinks/delete/<?= $this->data['editLink']->ID ?>'">
                        <i class="fas fa-trash fa-2x"></i>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="p-5">
                        <form action="/app/settings/mylinks/save/<?= $this->data['editLink']->ID ?>" method="POST">

                            <div class="form-row">
                                <div class="form-group col-12 col-md-6">
                                    <label for="title">Title</label>
                                    <input class="form-control" type="text" name="title" placeholder="Title" value="<?= $this->data['editLink']->Title ?>">
                                </div>
                                <div class="form-group col-12 col-md-6">
                                    <label for="url1">Url</label>
                                    <input class="form-control" type="text"  name="url" placeholder="Url" value="<?= $this->data['editLink']->Url ?>">
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-6 col-md-4">
                                    <label>Order</label>
                                    <select class="form-control" name="ordering">
                                        <? foreach (range(1, 5) as $number ): ?>
                                            <? if ($this->data['editLink']->Ordering == $number): ?>
                                                <option value="<?= $number ?>" selected><?= $number ?></option>
                                            <? else: ?>
                                                <option value="<?= $number ?>"><?= $number ?></option>
                                            <? endif; ?>
                                        <? endforeach; ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-12">
                                    <? foreach ($this->data['availableIcons'] as $icon): ?>
                                        <div class="select-icon-item float-left <?= $icon == $this->data['editLink']->IconClass? 'selected': '' ?>"
                                        data-icon="<?= $icon ?>">
                                            <i class="p-2 <?= $icon ?> fa-2x" ></i>
                                        </div>
                                    <? endforeach; ?>
                                    <input id="selectedIcon" type="hidden" name="iconClass" value="<?= $this->data['editLink']->IconClass ?>" />
                                </div>

                            </div>
                            <div class="form-group">
                                <div>
                                    <div
                                      class="float-left btn btn-outline-secondary text-secondary"
                                      onclick="window.location.href='/app/settings/mylinks'">
                                        Cancel
                                    </div>
                                    <button type="submit" class="float-right btn btn-secondary">Save</button>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>
<? endif; ?>

<table class="table table-hover mylinks-list">
    <thead>
    <th class="col-icon" scope="col"></th>
    <th class="col-title" scope="col">Title</th>
    <th class="col-url">Url</th>
    <th class="col-ordering">Order</th>
    <th class="col-actions"></th>
    </thead>
    <tbody>
    <?php foreach ($this->data['myLinks'] as $myLink): ?>
        <tr class="myLink-item text-secondary">
            <td><i class="<?= $myLink->IconClass ?> fa-2x"></i></td>
            <td><a class="text-secondary" href="<?= $myLink->Url ?>" target="_blank"><?= $myLink->Title; ?></a></td>
            <td><a class="text-secondary" href="<?= $myLink->Url ?>" target="_blank"><?= $myLink->Url; ?></td>
            <td><?= $myLink->Ordering ?></td>
            <td>
                <div class="float-right">
                    <a class="text-secondary" href="/app/settings/mylinks/edit/<?= $myLink->ID ?>">
                        <i class="far fa-edit fa-2x px-1"></i>
                    </a>
<!--                    <a class="text-secondary" href="/app/settings/mylinks/down/--><?//= $myLink->ID ?><!--">-->
<!--                        <i class="fas fa-chevron-circle-down fa-2x px-1"></i>-->
<!--                    </a>-->
<!--                    <a class="text-secondary" href="/app/settings/mylinks/up/--><?//= $myLink->ID ?><!--">-->
<!--                        <i class="fas fa-chevron-circle-up fa-2x px-1"></i>-->
<!--                    </a>-->


                </div>
            </td>

        </tr>
    <?php endforeach; ?>

    </tbody>
</table>
