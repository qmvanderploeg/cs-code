RightNow.namespace('Custom.Widgets.mylinks.MyLinksSettings');
Custom.Widgets.mylinks.MyLinksSettings = RightNow.Widgets.extend({

    /**
     * Constructor
     */
    constructor: function() {
        var self = this;
        $('.select-icon-item').click(function (event) {
            var elem = $(this);
            self.selectIcon(elem);
        });

        $('#new-link .select-icon-item').first().addClass('selected');
    },

    /**
     * Select Icon
     */
    selectIcon: function(element) {

        $('input[name=iconClass]').val(element.data('icon'));

        $('.select-icon-item').removeClass('selected');
        element.addClass('selected');
    }

});