<div class="row">
    <div class="col-6 border-right">
        <h4 class="text-center">Widgets Enabled</h4>
        <ul id="widgetsEnabled" class="connectedSortable">
            <? foreach ($this->data['enabledWidgets'] as $enabledWidget): ?>
            <li class="<?= $enabledWidget->Classes ?>" data-id="<?= $enabledWidget->ID ?>">
                <div>
                    <?= $enabledWidget->Title; ?>
                </div>
            </li>
            <? endforeach; ?>
        </ul>

    </div>
    <div class="col-6">
        <h4 class="text-center">Available Widgets</h4>
        <ul id="widgetsAvailable" class="connectedSortable">
            <? foreach ($this->data['availableWidgets'] as $availableWidget): ?>
                <li class="<?= $availableWidget->Classes ?>" data-id="<?= $availableWidget->ID ?>">
                    <div>
                        <?= $availableWidget->Title; ?>
                    </div>
                </li>
            <? endforeach; ?>
        </ul>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <form action="/app/settings/dashboard/save/1" method="POST">
        <input id="widget-selection" type="hidden" name="widget-selection" value=""/>
            <button type="submit" class="float-right btn btn-outline-secondary">Save</button>
        </form>
    </div>
</div>