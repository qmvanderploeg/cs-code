<?php

namespace Custom\Widgets\dashboard;

use Custom\Models\ContactDashboardWidget;
use Custom\Models\DashboardWidget;
use RightNow\Models\Contact;

/**
 * Class Dashboard
 * @package Custom\Widgets\Start\Dashboard
 */
class DashboardSettings extends \RightNow\Libraries\Widget\Base
{
    /**
     * @var DashboardWidget
     */
    protected $dashboardWidgetModel;

    /**
     * @var ContactDashboardWidget
     */
    protected $contactDashboardWidgetModel;

    /**
     * @var Contact $contact
     */
    protected $contact;

    /**
     * Dashboard constructor.
     *
     * @param $manifestAttributes
     */
    public function __construct($manifestAttributes)
    {
        parent::__construct($manifestAttributes);

        $this->CI->load->library('AutoLoad');
        $this->dashboardWidgetModel = $this->CI->model('custom/DashboardWidget');
        $this->contactDashboardWidgetModel = $this->CI->model('custom/ContactDashboardWidget');
        $this->contact = $this->CI->currentcontact->current();
    }

    /**
     * Get the data for the dashboard settings
     */
    public function getData()
    {
        $contactDashboardWidgets = $this->contactDashboardWidgetModel->getForContact($this->contact->ID);

        if (getUrlParm('reset') == 1) {
            foreach ($contactDashboardWidgets as $contactDashboardWidget) {
                $contactDashboardWidget->destroy();
            }
        }

        if (getUrlParm('save') == 1) {

            $input = $_POST['widget-selection'];

            $dashboardWidgetIDS = explode(',', $input);

            foreach ($contactDashboardWidgets as $contactDashboardWidget) {
                // remove not existing anymore
                if (!in_array($contactDashboardWidget->DashboardWidgetID->ID, $dashboardWidgetIDS)) {
                    $contactDashboardWidget->destroy();
                }
            }

            foreach ($dashboardWidgetIDS as $key => $dashboardWidgetID) {
                if ($dashboardWidgetID != 0) {
                    $this->contactDashboardWidgetModel->updateOrCreate($this->contact->ID, (int) $dashboardWidgetID, $key+1);
                }
            }

            header('Location: /app/settings/dashboard');
        }



        // get current widgets for contact if none, only pick up the ones that are required
        $enabledWidgets = $this->getEnabledWidgets($contactDashboardWidgets);

        foreach ($enabledWidgets as &$enabledWidget) {
            $this->setClass($enabledWidget);
        }

        $availableWidgets = $this->getAvailableWidgets($contactDashboardWidgets);

        foreach ($availableWidgets as &$availableWidget) {
            $this->setClass($availableWidget);
        }

        $this->data['enabledWidgets'] = $enabledWidgets;
        $this->data['availableWidgets'] = $availableWidgets;
    }

    /**
     * Get the Widgets that are enabled
     *
     * @param array $contactDashboardWidgets
     *
     * @return array|mixed
     */
    private function getEnabledWidgets($contactDashboardWidgets)
    {

        $dashboardWidgets = array();

        if (count($contactDashboardWidgets) === 0) {
            $dashboardWidgets = $this->dashboardWidgetModel->get();
        } else {

            foreach ($contactDashboardWidgets as $contactDashboardWidget) {

                $dashboardWidget = $contactDashboardWidget->DashboardWidgetID;

                if ($dashboardWidget) {

                    $dashboardWidget->Order = $dashboardWidget->Type === 'required' ? $dashboardWidget->DefaultOrder : $contactDashboardWidget->Ordering;

                    $dashboardWidgets[] = $dashboardWidget;
                }
            }

            usort($dashboardWidgets, function ($a, $b) {

                if ($a->Order === $b->Order) {
                    return 0;
                }

                return ($a->Order < $b->Order) ? -1 : 1;
            });
        }

        return $dashboardWidgets;

    }

    /**
     * Get all the available widget the Concat doesn't have yet.
     *
     * @param array $contactDashboardWidgets
     *
     * @return mixed
     */
    private function getAvailableWidgets($contactDashboardWidgets)
    {
        $availableWidgets = [];

        foreach ($this->dashboardWidgetModel->getAvailable() as $availableWidget) {
            if (!count(array_filter($contactDashboardWidgets, function ($item) use ($availableWidget) {
               return $item->DashboardWidgetID !== null && $item->DashboardWidgetID->ID === $availableWidget->ID;
            }))) {
                $availableWidgets[] = $availableWidget;
            }
        }

        return $availableWidgets;

    }

    private function setClass(&$dashboardWidget)
    {
        $classes = '';

        if ($dashboardWidget->Position !== 'fixed') {
            $classes .= ' sortable-item';
        } else {
            $classes .= ' fixed';
        }

        if ($dashboardWidget->Type === 'required') {
            $classes .= ' required';
        }


        $dashboardWidget->Classes = trim($classes);

    }

}