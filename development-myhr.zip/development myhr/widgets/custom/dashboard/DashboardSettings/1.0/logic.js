RightNow.namespace('Custom.Widgets.dashboard.DashboardSettings');
Custom.Widgets.dashboard.DashboardSettings = RightNow.Widgets.extend({

    /**
     * Constructor
     */
    constructor: function() {

        var ids = [];
        $("#widgetsEnabled li").each(function(i, el) {
            ids.push($(this).data('id'));
        });

        console.warn(ids.toString());

        $('#widget-selection').val(ids.toString());

        $(function () {
            $( "#widgetsEnabled" ).sortable({
                items: '.sortable-item',
                connectWith: "#widgetsAvailable",
                stop: function (event, ui) {
                    var ids = [];
                    $("#widgetsEnabled li").each(function(i, el) {
                        ids.push($(this).data('id'));
                    });

                    console.warn(ids.toString());

                    $('#widget-selection').val(ids.toString());
                }
            }).disableSelection();

            $( "#widgetsAvailable" ).sortable({
                items: '.sortable-item',
                connectWith: "#widgetsEnabled",
                cancel: ".disabled-sort-item",
                receive: function (event, ui) {
                  if (ui.item.hasClass('required')) {
                      $(ui.sender).sortable('cancel');
                  }
                },
                stop: function (event, ui) {
                    var ids = [];
                    $("#widgetsEnabled li").each(function(i, el) {
                        ids.push($(this).data('id'));
                    });

                    $('#widget-selection').val(ids.toString());
                }
            }).disableSelection();
        });

        if(!jQuery.ui)
        {
            alert('no ui');
        }
    },

});