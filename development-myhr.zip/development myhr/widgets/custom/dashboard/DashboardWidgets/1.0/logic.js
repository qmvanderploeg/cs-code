RightNow.namespace('Custom.Widgets.dashboard.DashboardWidgets');
Custom.Widgets.dashboard.DashboardWidgets = RightNow.Widgets.extend({

    /**
     * Constructor
     */
    constructor: function() {

    },

});