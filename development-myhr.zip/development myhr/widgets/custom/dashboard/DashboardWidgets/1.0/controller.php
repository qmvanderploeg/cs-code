<?php

namespace Custom\Widgets\dashboard;

use Custom\Models\ContactDashboardWidget;
use Custom\Models\DashboardWidget;
use RightNow\Models\Contact;

/**
 * Class Dashboard
 * @package Custom\Widgets\Start\Dashboard
 */
class DashboardWidgets extends \RightNow\Libraries\Widget\Base
{
    /**
     * @var DashboardWidget
     */
    protected $dashboardWidgetModel;

    /**
     * @var ContactDashboardWidget
     */
    protected $contactDashboardWidgetModel;

    /**
     * @var Contact $contact
     */
    protected $contact;

    /**
     * Dashboard constructor.
     *
     * @param $manifestAttributes
     */
    public function __construct($manifestAttributes)
    {
        parent::__construct($manifestAttributes);

        $this->CI->load->library('AutoLoad');
        $this->dashboardWidgetModel = $this->CI->model('custom/DashboardWidget');
        $this->contactDashboardWidgetModel = $this->CI->model('custom/ContactDashboardWidget');
        $this->contact = $this->CI->currentcontact->current();
    }

    /**
     * Get the Dashboard Widgets to show on the start page.
     *
     * @return void
     */
    public function getData()
    {
        $contactDashboardWidgets = $this->contactDashboardWidgetModel->getForContact($this->contact->ID);

        $dashboardWidgets = array();

        if (count($contactDashboardWidgets) === 0) {
            $dashboardWidgets = $this->dashboardWidgetModel->get();


        } else {

            foreach ($contactDashboardWidgets as $contactDashboardWidget) {

                $dashboardWidget = $contactDashboardWidget->DashboardWidgetID;

                if ($dashboardWidget) {

                    $dashboardWidget->Order = $dashboardWidget->Type === 'required' ? $dashboardWidget->DefaultOrder : $contactDashboardWidget->Ordering;

                    $dashboardWidgets[] = $dashboardWidget;
                }
            }

            usort($dashboardWidgets, function($a , $b) {

                if ($a->Order === $b->Order) {
                    return 0;
                }

                return ($a->Order < $b->Order) ? -1 : 1;
            });

        }

        $this->data['dashboardWidgets'] = $dashboardWidgets;
    }
}