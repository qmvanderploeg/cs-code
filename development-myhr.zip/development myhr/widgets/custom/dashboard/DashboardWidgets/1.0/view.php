<?php foreach ($this->data['dashboardWidgets'] as $dashboardWidget): ?>
    <div class="widget-block mt-3">
        <? if($dashboardWidget->Path ==  'custom/notifications/Dashboard'): ?>
              <rn:widget path="custom/notifications/Dashboard"/>
        <? endif; ?>
        <? if($dashboardWidget->Path == 'custom/dashboard/widgets/MyHRDashboardWidget'): ?>
            <rn:widget path="custom/dashboard/widgets/MyHRDashboardWidget"/>
        <? endif; ?>
        <? if($dashboardWidget->Path == 'custom/dashboard/widgets/MomentsDashboardWidget'): ?>
            <rn:widget path="custom/dashboard/widgets/MomentsDashboardWidget"/>
        <? endif; ?>
        <? if($dashboardWidget->Path == 'custom/dashboard/widgets/MyLinksDashboardWidget'): ?>
            <rn:widget path="custom/dashboard/widgets/MyLinksDashboardWidget"/>
        <? endif; ?>
        <!-- Favorite Topics-->
        <!-- Favorite Answers-->
        <!-- Selection of Categories-->
    </div>



<?php endforeach; ?>

