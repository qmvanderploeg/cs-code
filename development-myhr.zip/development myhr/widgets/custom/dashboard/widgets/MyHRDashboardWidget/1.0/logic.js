RightNow.namespace('Custom.Widgets.dashboard.widgets.MyHRDashboardWidget');
Custom.Widgets.dashboard.widgets.MyHRDashboardWidget = RightNow.Widgets.extend({

    /**
     * Constructor
     */
    constructor: function() {

    },

});