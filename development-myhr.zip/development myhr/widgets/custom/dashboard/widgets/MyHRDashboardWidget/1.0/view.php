<div class="pt-3 px-5">
    <div class="row">
        <div class= "col-12">
            <h4>My HR Self-Services</h4>
        </div>
    </div>
    <div class="row my-2">
        <div class="col-4 col-md-2 text-center">
            <a class="text-secondary" href="#">
                <i class="far fa-users fa-2x"></i>
                <p>Personal Team Data & Transfer</p>
            </a>
        </div>
        <div class="col-4 col-md-2 text-center">
            <a class="text-secondary" href="#">
                <i class="far fa-clock fa-2x"></i>
                <p>Working Time & Time Off</p>
            </a>
        </div>
        <div class="col-4 col-md-2 text-center">
            <a class="text-secondary" href="#">
                <i class="fas fa-hand-holding-usd fa-2x"></i>
                <p>Pay & Benefits</p>
            </a>
        </div>
        <div class="col-4 col-md-2 text-center">
            <a class="text-secondary" href="#">
                <i class="far fa-user-graduate fa-2x"></i>
                <p>Performance & Talent Development</p>
            </a>
        </div>
        <div class="col-6 col-md-4 text-right align-text-bottom">
            <a class="float-right text-secondary" href="#">More MyHr Self-Services <i class="fas fa-arrow-circle-right"></i></a>
        </div>
    </div>
</div>
