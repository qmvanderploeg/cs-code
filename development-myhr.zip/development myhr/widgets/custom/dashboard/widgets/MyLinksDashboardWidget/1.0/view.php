<div class="pt-3 pl-5 pr-3">
    <div class="row">
        <div class= "col-12">
            <h4>My Links</h4>
        </div>
    </div>
    <div class="row my-2">
        <? foreach ($this->data['myLinks'] as $myLink): ?>
        <div class="col-4 col-md-2 text-center">
            <a class="text-secondary" href="<?= $myLink->Url ?>" target="_blank">
                <i class="<?= $myLink->IconClass ?> fa-2x"></i>
                <p><?= $myLink->Title ?> </p>
            </a>
        </div>
        <? endforeach; ?>
    </div>
    <div class="row">
        <div class="col-12 text-right align-text-bottom">
            <a class="mr-2 text-secondary" href="/app/mylinks">more <i class="fas fa-arrow-right"></i></a>
        </div>
    </div>
</div>
