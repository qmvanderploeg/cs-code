RightNow.namespace('Custom.Widgets.dashboard.widgets.MyLinksDashboardWidget');
Custom.Widgets.dashboard.widgets.MyLinksDashboardWidget = RightNow.Widgets.extend({

    /**
     * Constructor
     */
    constructor: function() {

    },

});