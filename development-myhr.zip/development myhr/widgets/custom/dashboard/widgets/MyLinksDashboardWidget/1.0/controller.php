<?php

namespace Custom\Widgets\dashboard\widgets;

use Custom\Models\MyLink;
use RightNow\Models\Contact;

/**
 * Class MyHRDashboardWidget
 * @package Custom\Widgets\dashboard\widget
 */
class MyLinksDashboardWidget extends \RightNow\Libraries\Widget\Base
{
    /**
     * @var MyLink $myLinkModel
     */
    protected $myLinkModel;

    /**
     * @var Contact $contact
     */
    protected $contact;

    /**
     * MyLinksDashboardWidget constructor.
     *
     * @param $manifestAttributes
     */
    public function __construct($manifestAttributes)
    {
        parent::__construct($manifestAttributes);

        $this->CI->load->library('AutoLoad');
        $this->myLinkModel = $this->CI->model('custom/MyLink');
        $this->contact = $this->CI->currentcontact->current();
    }

    /**
     * Get the data for the widget
     *
     * @return void
     */
    public function getData()
    {
        $myLinks = $this->myLinkModel->getForContact($this->contact->ID, 1);

        $this->data['myLinks'] = $myLinks;
    }


}