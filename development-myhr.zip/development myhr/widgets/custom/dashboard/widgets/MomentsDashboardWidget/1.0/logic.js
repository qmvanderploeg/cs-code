RightNow.namespace('Custom.Widgets.dashboard.widgets.MomentsDashboardWidget');
Custom.Widgets.dashboard.widgets.MomentsDashboardWidget = RightNow.Widgets.extend({

    /**
     * Constructor
     */
    constructor: function() {

    },

});