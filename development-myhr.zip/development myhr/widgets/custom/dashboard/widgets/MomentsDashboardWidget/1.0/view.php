<div class="pt-3 px-5">
    <div class="row">
        <div class= "col-12">
            <h3>Moments that Matter</h3>
        </div>
    </div>
    <div class="row my-2">
        <div class="col-4 col-md-2 text-center">
            <a class="text-secondary" href="#">
                <i class="far fa-user fa-2x"></i>
                <p>My Profile</p>
            </a>
        </div>
        <div class="col-4 col-md-2 text-center">
            <a class="text-secondary" href="/app/moments/time_tracking">
                <i class="fas fa-stopwatch fa-2x"></i>
                <p>Time Tracking</p>
            </a>
        </div>
        <div class="col-4 col-md-2 text-center">
            <a class="text-secondary" href="#">
                <i class="fas fa-balance-scale fa-2x"></i>
                <p>Leave Balance</p>
            </a>
        </div>
        <div class="col-4 col-md-2 text-center">
            <a class="text-secondary" href="#">
                <i class="far fa-trophy fa-2x"></i>
                <p>My Performance</p>
            </a>
        </div>
        <div class="col-6 col-md-4 text-right align-text-bottom">
            <a class="text-secondary" href="#">More moments that matters suited for you<i class="fas fa-arrow-circle-right"></i></a>
        </div>
    </div>
</div>
