RightNow.namespace('Custom.Widgets.dashboard.widgets.NewsAndNotificationDashboardWidget');
Custom.Widgets.dashboard.widgets.NewsAndNotificationDashboardWidget = RightNow.Widgets.extend({

    /**
     * Constructor
     */
    constructor: function() {

    },

});