<div class="py-3 px-5">

    <div class="row">
        <div class="col-12 mb-2">
            <h2>Hello <?= $this->data['contact']->Name->First ?></h2>
            <p>Welcome to your personal my HR portal home page. </p>
        </div>

    </div>
    <div class="row">
        <div class="col-12">
            <h5>Check our your lastest News & Notifications</h5>
        </div>

    </div>
    <div class="row">
        <div class="col-12 col-md-6">
            <h6>News</h6>
            <div class="col-12">
                <div class="notification-item">
                    <div class="row">
                        <div class="col-1">
                            <i class="far fa-envelope fa-2x "></i>
                        </div>
                        <div class="col-11">
                            <div>
                                <span class="title">Lorem ipsum dolor sit amet</span>
                                <span class="float-right">21 July</span>
                            </div>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
                                aliqua ...
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12">
                <div class="notification-item">
                    <div class="row">
                        <div class="col-1">
                            <i class="far fa-envelope fa-2x "></i>
                        </div>
                        <div class="col-11">
                            <div>
                                <span class="title">Lorem ipsum dolor sit amet</span>
                                <span class="float-right">18 July</span>
                            </div>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
                                aliqua...
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12">
                <div class="notification-item">
                    <div class="row">
                        <div class="col-1">
                            <i class="far fa-envelope fa-2x "></i>
                        </div>
                        <div class="col-11">
                            <div>
                                <span class="title">Lorem ipsum dolor sit amet</span>
                                <span class="float-right">16 July</span>
                            </div>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
                                aliqua ...
                            </p>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div class="col-12 col-md-6">
            <h6>Notifications</h6>
            <? foreach ($this->data['notifications'] as $notification): ?>
            <div class="col-12">
                <div class="notification-item" onclick="window.location.href='/app/notifications/list/show/<?= $notification->ID ?>'">
                    <div class="row">
                        <div class="col-1">
                            <i class="<?= $notification->IconClass ?> fa-2x "></i>
                        </div>
                        <div class="col-11">
                            <div>
                                <span class="title"><?= $notification->Title ?></span>
                                <? if ($notification->status == 'unread'): ?>
                                <span class="text-danger p-1">new</span>
                                <? endif; ?>
                                <span class="float-right"><?= $notification->createdAt ?></span>
                            </div>
                            <p><?= substr($notification->Text, 0, 100) ?></p>
                        </div>
                    </div>
                </div>

            </div>
            <? endforeach; ?>
        </div>


    </div>
    <div class="row">
        <div class="col-12 col-md-6 text-right">
            <a class="mr-2 text-secondary" href="#"><span>more <i class="fas fa-arrow-right"></i></span></a>
        </div>
        <div class="col-12 col-md-6 text-right">
            <a class="mr-2 text-secondary" href="/app/notifications/list"><span>more <i class="fas fa-arrow-right"></i></span></a>
        </div>
    </div>
</div>