<?php

namespace Custom\Widgets\mynews;

use Custom\Models\Notification;
use RightNow\Models\Contact;

/**
 * Class Overview
 * @package Custom\Widgets\notifications
 */
class Overview extends \RightNow\Libraries\Widget\Base
{
    /**
     * @var Contact $contact
     */
    protected $contact;

    /**
     * FullList constructor.
     *
     * @param $attrs
     */
    public function __construct($attrs)
    {
        parent::__construct($attrs);

        $this->CI->load->library('AutoLoad');
        $this->contact = $this->CI->currentcontact->current();
    }

    /**
     * Get the Notification Items
     *
     * @return void
     */
    public function getData()
    {

    }
}