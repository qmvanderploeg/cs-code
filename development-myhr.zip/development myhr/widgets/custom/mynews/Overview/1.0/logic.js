RightNow.namespace('Custom.Widgets.mynews.Overview');
Custom.Widgets.mynews.Overview = RightNow.Widgets.extend({

    /**
     * Constructor
     */
    constructor: function() {

    },

});