<div class="my-2">
    <div class="row">
        <div class="col-12 col-md-6">
            <div class="d-flex align-items-center">
                <div class="row">
                    <div class="col-6"></div>
                </div>
                <div onclick="window.location.href='app/notifications/list/reset/1'"><i class="far fa-bell fa-3x"></i></div>
                <h3 class="ml-3">MyHr news</h3>
            </div>
        </div>
    </div>
    <div class="row my-3">
        <div class="col-12">
            <table class="table table-hover notification-list">
                <thead>
                <th class="col-icon" scope="col"></th>
                <th class="col-date" scope="col">Received</th>
                <th class="col-description" scope="col">Title</th>
                <th class="col-link" scope="col"></th>
                </thead>
                <tbody>
                <?php foreach (range(10, 1) as $dayNumber): ?>
                <tr>
                    <td><i class="fas fa-bell"></i></td>
                    <td><?= $dayNumber ?> July, 2020</td>
                    <td>Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</td>
                    <td>Go to the News</td>
                </tr>
                <?php endforeach; ?>

                </tbody>
            </table>
        </div>
    </div>
</div>